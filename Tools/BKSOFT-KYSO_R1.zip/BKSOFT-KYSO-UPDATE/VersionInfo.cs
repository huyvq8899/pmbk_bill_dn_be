﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KYSO_UPDATE
{
    public class VersionInfo
    {
        public string Version { set; get; }

        public string Date { set; get; }

        public string Link { set; get; }
    }
}
