﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BKSOFT_KYSO
{
    public class TTNKy
    {
        public string Ten { set; get; }

        public string SDThoai { set; get; }

        public string DChi { set; get; }

        public string TenP1 { set; get; }

        public string TenP2 { set; get; }
    }

    public class NBan
    {
        public string Ten { set; get; }

        public string MST { set; get; }

        public string DChi { set; get; }

        public string SDThoai { set; get; }

        public string DCTDTu { set; get; }

        public string STKNHang { set; get; }

        public string TNHang { set; get; }

        public string Fax { set; get; }

        public string Website { set; get; }

        public string TenP1 { set; get; }

        public string TenP2 { set; get; }
    }
}
